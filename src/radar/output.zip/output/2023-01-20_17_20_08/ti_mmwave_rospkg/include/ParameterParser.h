#ifndef _PARAM_PARSER_CLASS_
#define _PARAM_PARSER_CLASS_

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "ti_mmwave_rospkg/mmWaveCLI.hpp"
#include <nodelet/nodelet.hpp>
#include <pluginlib/class_list_macros.hpp>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cstdio>
#include <sstream>
#include <string>
#include <vector>

namespace ti_mmwave_rospkg {

class ParameterParser : public nodelet::Nodelet{

  public:
  	
  	ParameterParser();
  	void ParamsParser(ti_mmwave_rospkg::mmWaveCLI &srv, rclcpp::NodeHandle &n);
	void CalParams(rclcpp::NodeHandle &nh);

  private:
    
    virtual void onInit();
    
    ti_mmwave_rospkg::mmWaveCLI srv;

};
}
#endif
